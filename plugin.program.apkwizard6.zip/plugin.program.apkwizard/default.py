#######################################################################
#Import Modules Section
import xbmcplugin, xbmcaddon
import sys
import urllib
import re
import base_info
import glo_var
global parse

###################################################################################
#Main Menu
def MainMenu():
    if ('android' in base_info.platform()) or (glo_var.DEVELOPER == True):
        base_info.addDir2('[COLOR springgreen]News[/COLOR]','http://','news',glo_var.ICON,glo_var.ART,'')
        base_info.addDir2('','url','',glo_var.ICON,glo_var.ART,'')
        base_info.addDir('Kodi Menu','url','kodi_menu',glo_var.ICON,glo_var.ART,'')
        base_info.addDir('Apps Menu','url','apps_menu',glo_var.ICON,glo_var.ART,'')
    else:
        base_info.addDir2('[COLOR red][B]This Add-on is made for Android Devices[/B][/COLOR]', 'http://', 'mainmenu', glo_var.ICON, glo_var.ART, '')
    xbmc.executebuiltin('Container.SetViewMode(50)')


####################################################################################    

###################################################################################
#Kodi Menu
def Kodi_Menu():
    base_info.addDir2('[COLOR dodgerblue]Kodi APK Menu[/COLOR]', 'http://', 'section', glo_var.ICON, glo_var.ART, '')
    base_info.addDir2('[COLOR red]============================================[/COLOR]', 'http://', 'section', glo_var.ICON, glo_var.ART, '')
    base_info.addDir2(' ', 'http://', 'section', glo_var.ICON, glo_var.ART, '')
    link = base_info.OPEN_URL(glo_var.KODI_FILE).replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?ersion="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,image,fanart,version,description in match:
        base_info.addDir2(name + ' v' + version, url, 'apkinstall', image, fanart, description)
        xbmc.executebuiltin('Container.SetViewMode(50)')
        



####################################################################################    

###################################################################################
#Apps Menu
def apps_menu():
    base_info.addDir2('[COLOR dodgerblue]Andriod APP APK Menu[/COLOR]', 'http://', 'section', glo_var.ICON, glo_var.ART, '')
    base_info.addDir2('[COLOR red]============================================[/COLOR]', 'http://', 'section', glo_var.ICON, glo_var.ART, '')
    base_info.addDir2(' ', 'http://', 'section', glo_var.ICON, glo_var.ART, '')
    link = base_info.OPEN_URL(glo_var.APPS_FILE).replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?ersion="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,image,fanart,version,description in match:
        base_info.addDir2(name + ' v' + version, url, 'apkinstall', image, fanart, description)
        xbmc.executebuiltin('Container.SetViewMode(50)')
###################################################################################

####################################################################################
#Define Paramaters
def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
        return param

params=get_params()
url         = None
name        = None
version     = None
mode        = None
iconimage   = None
fanart      = None
description = None
try:     mode=urllib.unquote_plus(params["mode"])
except:  pass
try:     name=urllib.unquote_plus(params["name"])
except:  pass
try:     name=urllib.unquote_plus(params["version"])
except:  pass
try:     url=urllib.unquote_plus(params["url"])
except:  pass
try:     iconimage=urllib.unquote_plus(params["iconimage"])
except:  pass
try:     fanart=urllib.unquote_plus(params["fanart"])
except:  pass
try:     description=urllib.unquote_plus(params["description"])
except:  pass

#######################################################################

#######################################################################
# Below we are creating the different modes
if mode==None               : MainMenu()
elif mode=='kodi_menu'      : Kodi_Menu()
elif mode=='news'           : base_info.Update_News()
elif mode=='apps_menu'     : apps_menu()
elif mode=='apkinstall'     : base_info.apkInstaller(name, url)
#######################################################################

#######################################################################
#End of Directory
xbmcplugin.endOfDirectory(int(sys.argv[1]))
#######################################################################