#######################################################################
# Import Modules Section
import xbmc, xbmcaddon, xbmcgui, xbmcplugin, base64
import os
#######################################################################

#######################################################################
# Set this to True to see the menu on non-android devices for dev work
DEVELOPER           = False
#######################################################################

#######################################################################
# Primary Addon Variables
AddonID             = xbmcaddon.Addon().getAddonInfo('id')
ADDON               = xbmcaddon.Addon(id=AddonID)
HOME                = xbmc.translatePath('special://home/')
ADDONS              = os.path.join(HOME, 'addons')
USERDATA            = os.path.join(HOME, 'userdata')
ADDON_DATA          = xbmc.translatePath(os.path.join(USERDATA, 'addon_data'))
ownAddon            = xbmcaddon.Addon(id=AddonID)
URL                 = base64.b64decode(b'aHR0cDovL2xvZGdpYy5jby5uei9mYW5jeWluc3RhbGxlci8=')
NEWSURL             = base64.b64decode(b'aHR0cDovL2xvZGdpYy5jby5uei9mYW5jeWluc3RhbGxlci9uZXdzLnhtbA==')
ADDONTITLE          = base64.b64decode(b'W0NPTE9SIHNwcmluZ2dyZWVuXVtCXUZhbmN5Wy9CXVsvQ09MT1JdIFtDT0xPUiBzbm93XUluc3RhbGxlclsvQ09MT1Jd')
#######################################################################

#######################################################################
# Filename Variables 
BASEURL             = URL
KODI_FILE           = BASEURL + base64.b64decode(b'a29kaS50eHQ=')
APPS_FILE          = BASEURL + base64.b64decode(b'YXBwcy50eHQ=')
#######################################################################

#######################################################################
# Theme Variables
FONTHEADER          = base64.b64decode(b'Rm9udDE0')
FANART              = xbmc.translatePath(os.path.join('special://home/addons/' + AddonID, 'fanart.jpg'))
ICON                = xbmc.translatePath(os.path.join('special://home/addons/' + AddonID, 'icon.png'))
ART                 = xbmc.translatePath(os.path.join('special://home/addons/' + AddonID, 'resources/art/'))
#######################################################################

#######################################################################
ADDONDATA           = os.path.join(USERDATA, 'addon_data', AddonID)
dialog              = xbmcgui.Dialog()
DIALOG              = xbmcgui.Dialog()
dp                  = xbmcgui.DialogProgress()
DP                  = xbmcgui.DialogProgress()
LOG                 = xbmc.translatePath('special://logpath/')
PLUGIN              = os.path.join(ADDONS, AddonID)
skin                = xbmc.getSkinDir()
USER_AGENT          = base64.b64decode(b'TW96aWxsYS81LjAgKFdpbmRvd3M7IFU7IFdpbmRvd3MgTlQgNS4xOyBlbi1HQjsgcnY6MS45LjAuMykgR2Vja28vMjAwODA5MjQxNyBGaXJlZm94LzMuMC4z')
#######################################################################